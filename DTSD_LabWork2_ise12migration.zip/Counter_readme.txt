The following files were generated for 'Counter' in directory 
C:\Xilinx92i\DTSD_LabWork2:

Counter.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

Counter.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

Counter.sym:
   Please see the core data sheet.

Counter.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

Counter.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

Counter.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

Counter.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

Counter.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

Counter_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

Counter_readme.txt:
   Text file indicating the files generated and how they are used.

Counter_xmdf.tcl:
   Please see the core data sheet.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

